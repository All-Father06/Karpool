<?php
session_abort();
echo('<script>alert("Logout success")</script>');
echo('<script>window.location="index.html"</script>');
?>
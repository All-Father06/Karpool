<?php
$hostname="localhost";
$user="root";
$password="";
$db="pool";
$conn=mysqli_connect($hostname,$user,$password,$db);
?>